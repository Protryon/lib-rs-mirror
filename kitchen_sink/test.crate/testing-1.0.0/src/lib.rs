//! okay
pub fn nothing(){}
